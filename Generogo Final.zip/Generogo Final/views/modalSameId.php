<!DOCTYPE html>
<html id="modalpage">
  <head>
	<meta charset="utf-8"/>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap-theme.min.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<title>Genero'GO</title>
  </head>
  <body id="body-modal">
    <!--Modal-->
    <div id="mymodal" class="logerror">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-body">
              <p>L'identifiant existe déjà, réessayer avec un nouveau identifiant</p>
          </div>
          <div class="modal-footer">
           <a class="btn btn-primary" data-dismiss="modal" href="/signup">Réessayer</a>
         </div>
        </div>
      </div>
    </div>
    <!--End of modal-->
  </body>
</html>
<script src="../javascript/jquery.min.js"></script>
<script type="text/Javascript" src="../javascript/bootstrap.min.js"></script>
