<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<script type="text/javascript" src="script.js"></script>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <!--My stylesheet-->
  <link rel="stylesheet" type="text/css" href="css/style2.css">
  <!--Bootstrap style -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <!--MagicSuggest Combobox Style-->
  <link rel="stylesheet" type="text/css" href="css/magicsuggest-min.css">
  <!--Script calling-->
  <script src="javascript/jquery.min.js"></script>
  <!--Bootstrap script-->
  <scrip src="javascript/bootstrap.min.js" ></script>
  <!--script bootstrap nav animation-->
  <script src="javascript/bootstrap-collapse.js"></script>
	<title>Genero'GO Accueil</title>
</head>
<body>
<!-- multistep form -->
<form id="ovform" method="POST" action="register.php">
  <!-- fieldsets -->
  <fieldset>
    <h2 class="fs-title">Genero'GO</h2>
    <h3 class="fs-subtitle">Contactez : generogo@oodrive.com</h3>
  </fieldset>
</form>
</body>
</html>
